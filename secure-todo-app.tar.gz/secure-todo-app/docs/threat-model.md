Modelo de amenazas
Activos a proteger
• Datos de los usuarios.
• Lista de tareas.
• Configuración de la aplicación.
• Servidor donde se ejecuta la aplicación.
Amenazas identificadas
Cross Site Scripting (XSS)
Un atacante podría introducir código JavaScript malicioso mediante formularios.
SQL Injection
Un atacante podría manipular consultas a la base de datos.
Acceso no autorizado
Un usuario podría acceder a información para la que no tiene permisos.
Dependencias vulnerables
Bibliotecas externas podrían contener vulnerabilidades conocidas.
Denegación de servicio
Un atacante podría intentar saturar la aplicación mediante múltiples peticiones.
