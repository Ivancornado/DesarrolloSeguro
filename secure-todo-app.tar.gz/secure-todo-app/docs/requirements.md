Requisitos de la aplicación
Requisitos funcionales
• El usuario podrá crear tareas.
• El usuario podrá editar tareas existentes.
• El usuario podrá eliminar tareas.
• El usuario podrá marcar tareas como completadas.
• El usuario podrá visualizar todas las tareas registradas.
Requisitos de seguridad
• Todas las entradas de usuario deberán validarse.
• La aplicación deberá protegerse frente a ataques XSS.
• La aplicación deberá protegerse frente a inyecciones SQL.
• Los errores no deberán mostrar información sensible.
• Se aplicará el principio de mínimo privilegio.
• Las dependencias deberán mantenerse actualizadas.
• El acceso a la aplicación deberá estar controlado mediante autenticación
