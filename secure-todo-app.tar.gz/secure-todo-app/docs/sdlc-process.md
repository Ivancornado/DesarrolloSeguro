Aplicación del Secure Software
Development Life Cycle
1. Requisitos
Se identifican las funcionalidades y requisitos de seguridad de la aplicación.
2. Diseño
Se realiza un análisis de amenazas y se definen controles de seguridad.
3. Desarrollo
La aplicación se implementa siguiendo prácticas de programación segura.
4. Pruebas
Se realizan pruebas funcionales y pruebas de seguridad para detectar vulnerabilidades.
5. Despliegue
La aplicación se despliega mediante Docker en un entorno controlado.
6. Mantenimiento
Se monitorizan vulnerabilidades y se actualizan componentes cuando sea necesario.
