Secure To-Do Application
Descripción
Secure To-Do Application es una aplicación web para la gestión de tareas. Permite a los
usuarios crear, editar, completar y eliminar tareas de forma sencilla.
La aplicación se desarrolla siguiendo la metodología Secure Software Development Life Cycle
(S-SDLC) con el objetivo de integrar la seguridad en todas las fases del desarrollo.
Funcionalidades
• Crear tareas.
• Editar tareas.
• Eliminar tareas.
• Marcar tareas como completadas.
• Visualizar tareas pendientes.
Ejecución
La aplicación se ejecuta mediante Docker.
docker build -t secure-todo .
docker run -p 3000:3000 secure-todo
Acceso:
http://localhost:3000
Consideraciones de seguridad
Durante el diseño de la aplicación se han considerado las siguientes medidas:
• Validación de entradas de usuario.
• Protección frente a ataques XSS.
• Protección frente a inyecciones SQL.
• Gestión segura de errores.
• Control de acceso basado en privilegios mínimos.
• Actualización periódica de dependencias.
• Uso de contenedores Docker para aislamiento.
Aplicación del S-SDLC
Requisitos

Identificación de requisitos funcionales y de seguridad.
Diseño
Definición de controles de seguridad y análisis de amenazas.
Desarrollo
Aplicación de buenas prácticas de programación segura.
Pruebas
Ejecución de pruebas funcionales y de seguridad.
Despliegue
Uso de Docker para desplegar la aplicación en un entorno controlado.
Mantenimiento
Monitorización continua y corrección de vulnerabilidades detectadas.
