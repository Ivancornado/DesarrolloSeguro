Secure To-Do App

Aplicacion web para la gestion de tareas.

Funcionalidade:
-Crear tareas.
-Editar tareas.
-Eliminar tareas.
-Marcar tareas como completadas.
-Visualizar tareas pendientes.

La aplicaci'on se ejecuta mediante Docker y ha sido seleccionada como proyecto base para aplicar la metodolog'ia Secure Software Development Life Cycle (S-SDLC)
