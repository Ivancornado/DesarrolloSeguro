Pruebas de seguridad

Validaci'on de entradas
Comprobar que la aplicacion rechaza entradas maliciosas o invalidas.

Prueba XSS
Intentar introducir codigo JavaScript en los formularios para verificar que no se ejecuta.

Pruebas SQJ Injection
Introducir caracteres especiales y consultas maliciosas para comprobar que no afectan al sistema.

Control de acceso
Verificar que los usuarios solo acceden a los recursos autorizados.

Dependencias vulnerables
Analizar las librerias utilizadas mediante herramientas automaticas.
